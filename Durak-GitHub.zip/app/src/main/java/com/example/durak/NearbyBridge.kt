package com.example.durak

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject

/** Мост между игрой (JavaScript) и Nearby Connections. В игре он доступен как объект Android. */
class NearbyBridge(private val act: MainActivity, private val web: WebView) {
    private val client = Nearby.getConnectionsClient(act)
    private val service = "com.example.durak"

    private fun emit(o: JSONObject) = act.runOnUiThread {
        web.evaluateJavascript("window.onNative&&window.onNative($o)", null)
    }
    fun error(msg: String) = emit(JSONObject().put("e", "err").put("m", msg))

    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            p.asBytes()?.let { emit(JSONObject().put("e", "msg").put("id", id).put("d", String(it, Charsets.UTF_8))) }
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    private val connections = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            client.acceptConnection(id, payloads)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) emit(JSONObject().put("e", "open").put("id", id))
            else error("соединение отклонено")
        }
        override fun onDisconnected(id: String) = emit(JSONObject().put("e", "close").put("id", id))
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) =
            emit(JSONObject().put("e", "found").put("id", id).put("n", info.endpointName))
        override fun onEndpointLost(id: String) = emit(JSONObject().put("e", "lost").put("id", id))
    }

    @JavascriptInterface
    fun host(name: String) = act.withPerms {
        client.startAdvertising(
            name, service, connections,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        ).addOnFailureListener { error(it.message ?: "не удалось создать игру") }
    }

    @JavascriptInterface
    fun discover() = act.withPerms {
        client.startDiscovery(
            service, discovery,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        ).addOnFailureListener { error(it.message ?: "не удалось искать игры") }
    }

    @JavascriptInterface
    fun connect(id: String) {
        client.requestConnection("Игрок", id, connections)
            .addOnFailureListener { error(it.message ?: "не удалось подключиться") }
    }

    @JavascriptInterface
    fun send(id: String, data: String) {
        client.sendPayload(id, Payload.fromBytes(data.toByteArray(Charsets.UTF_8)))
    }

    @JavascriptInterface fun stopAdvertising() { client.stopAdvertising() }

    @JavascriptInterface
    fun stopAll() {
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
    }
}
